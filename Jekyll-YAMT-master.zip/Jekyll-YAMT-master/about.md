---
layout: default
title: About
---

# [YAMT - Yet Another Minimal Theme](https://yamt.netlify.app/)
See [Github](https://github.com/PandaSekh/Jekyll-YAMT).